﻿using System;
using System.Collections.Generic;

namespace LibraryManagement_Milestone1.Models
{
    public partial class Book
    {
        public Book()
        {
            Borrows = new HashSet<Borrow>();
        }

        public int BookId { get; set; }
        public string? Name { get; set; }
        public int? PageCount { get; set; }
        public int AuthorId { get; set; }
        public int TypeId { get; set; }

        public virtual Author Author { get; set; } = null!;
        public virtual BookType Type { get; set; } = null!;
        public virtual ICollection<Borrow> Borrows { get; set; }
    }
}
