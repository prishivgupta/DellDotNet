﻿using System;
using System.Collections.Generic;

namespace LibraryManagement_Milestone1.Models
{
    public partial class Type
    {
        public Type()
        {
            Books = new HashSet<Book>();
        }

        public int TypeId { get; set; }
        public string? Name { get; set; }

        public virtual ICollection<Book> Books { get; set; }
    }
}
