﻿using System;
using System.Collections.Generic;

namespace LibraryManagement_Milestone1.Models
{
    public partial class Student
    {
        public Student()
        {
            Borrows = new HashSet<Borrow>();
        }

        public int StudentId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Gender { get; set; }
        public int? Age { get; set; }

        public virtual ICollection<Borrow> Borrows { get; set; }
    }
}
